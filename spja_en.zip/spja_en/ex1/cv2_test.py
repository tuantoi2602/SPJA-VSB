def f(x):
    return x*(x - 2)

""" WRITE YOUR CODE """       

#print(filter_numbers([1.2, "sdas", 4, [12], 3.4, "12", -3, True, 5, 8.1]))
#print(check_brackets("(a+b)/(b*(a+c))"))
#print(check_brackets("(a+b))/((b*(a+c))"))
#print(check_brackets("(a+b)/(b*(a+c)"))
#print(fun_extrems(f, -5, 5))
#print(number_of_vowels("Technical University"))
